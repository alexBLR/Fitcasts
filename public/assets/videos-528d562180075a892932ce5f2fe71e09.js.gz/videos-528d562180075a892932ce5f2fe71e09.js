(function() {
  jQuery(function() {
    return $('.datepicker').datepicker({
      format: 'mm-dd-yyyy'
    });
  });

}).call(this);
