$('#new_callog').hide();
