(function() {
  jQuery(function() {
    return $('.datepicker').datepicker({
      format: 'yyyy-mm-dd'
    });
  });

}).call(this);
